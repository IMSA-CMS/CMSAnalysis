This directory contains source code dedicated to the `xxhsum` command line utility,
which is a user program of `libxxhash`.

Note that, in contrast with the library `libxxhash`, the command line utility `xxhsum` ships with GPLv2 license.
